import random

# reference set
permanentSet = ''' 
    0 1 2    09    13 14 15    22
    3 4 5  10  11  16 17 18  23  24
    6 7 8    12    19 20 21    25
    
    
    D A V    K    B N F    M
    U Z E  L   I  X O Y  W   T
    S C G    R    Q J P    H
'''
# trial project

# default box values
dBox1 = ["D", "A", "V", "U", "Z", "E", "S", "C", "G"]  # 0 - 8
dBox2 = ["K", "I", "R", "L"]  # 9 - 12
dBox3 = ["B", "N", "F", "X", "O", "Y", "Q", "J", "P"]  # 13 - 21
dBox4 = ["M", "T", "H", "W"]  # 22 - 25

# current box values
box1 = ["D", "A", "V", "U", "Z", "E", "S", "C", "G"]
box2 = ["K", "I", "R", "L"]
box3 = ["B", "N", "F", "X", "O", "Y", "Q", "J", "P"]
box4 = ["M", "T", "H", "W"]
boxes = [box1, box2, box3, box4]
boxes2 = box1 + box2 + box3 + box4


# post-shuffle box sample
def current_box():
    print(box1[0] + " " + box1[1] + " " + box1[2] + "    " +
          box2[0] + "    " +
          box3[0] + " " + box3[1] + " " + box3[2] + "    " +
          box4[0] + "\n" +

          box1[3] + " " + box1[4] + " " + box1[5] + "  " +
          box2[1] + "   " + box2[2] + "  " +
          box3[3] + " " + box3[4] + " " + box3[5] + "  " +
          box4[1] + "   " + box4[2] + "  \n" +

          box1[6] + " " + box1[7] + " " + box1[8] + "    " +
          box2[3] + "    " +
          box3[6] + " " + box3[7] + " " + box3[8] + "    " +
          box4[3]
          )


# prompts and prints the code
def string_to_int():
    string = ""
    code = list(map(str, interpret_string()))
    for x in range(len(code)):
        string = (string + code[x] + "  ")
    print(string)


# converts the string into numbers
def interpret_string():
    text = input("enter a string! ").upper()
    encoded = []
    print(text)
    code = [x for x in text]
    for x in range(len(code)):
        if code[x] == " ":
            encoded.append(create_shuffle())
        else:
            for i in range(len(boxes)):
                num = (box_check(code[x], i))
                if num is None:
                    num = 0
                else:
                    encoded.append(num)
    return encoded

# creates a number shuffle whenever there is a space
def create_shuffle():
    randint = random.randrange(20) + 1
    print("shuffle: ",str(randint))
    shuffle_call(randint)
    return randint
    
        

# checks which box and what index the character is
def box_check(x, i):
    codeletter = x
    boxnumber = i
    if codeletter in boxes[i]:
        number = (boxes[i].index(codeletter))
        return box_number(boxnumber, number)


# Fixes the box number
def box_number(boxnumber, number):
    if boxnumber > 0:
        number += 9
    if boxnumber > 1:
        number += 4
    if boxnumber > 2:
        number += 9
    return number


# prompts and deciphers code
def int_to_string():
    message = interpret_int()
    decoded = ""
    for i in range(len(message)):
        decoded += (str(message[i]))
    print(decoded)


# prompts a code to begin then print code
def interpret_int():
    text = input("enter a code seperated by double spaces: ")
    digits = [x for x in text]
    coded = (scan_digits(digits))
    message = decode(coded)
    return message


# combines message into proper numbers and lists
def scan_digits(code):
    current = ""
    skip = 0
    send = []
    for x in range(len(code)):
        if code[x] == " ":
            skip = skip + 1
            if skip == 2:
                send.append(current)
                skip = 0
                current = ""
        elif code[x] == "_":
            current = "_"
        else:
            current += code[x]
            skip = 0

    return send


def get_letter(boxindex, boxnumber):
    code = []

    for i in range(len(boxnumber)):
        if boxnumber[i] == "_":
            code.append(" ")
        else:
            print(boxes[boxnumber[i]].index(boxindex[i]))


def decode(coded):
    message = []
    for i in range(len(coded)):
        if coded[i] == "_":
            message.append("_")
        else:
            index = int(coded[i])
            message.append(boxes2[index])
    return message


# START OF THE SHUFFLE FUNCTIONS


# even: rotate clockwise
def shuffle_even():
    
    # shuffles the first box
    (
        boxes[0][0],
        boxes[0][1],
        boxes[0][2],
        boxes[0][3],
        boxes[0][4],
        boxes[0][5],
        boxes[0][6],
        boxes[0][7],
        boxes[0][8]
    ) = (
        boxes[0][3],
        boxes[0][0],
        boxes[0][1],
        boxes[0][6],
        boxes[0][4],
        boxes[0][2],
        boxes[0][7],
        boxes[0][8],
        boxes[0][5]
    )

    # shuffles the second box
    (
        boxes[1][0],
        boxes[1][1],
        boxes[1][2],
        boxes[1][3]
    ) = (
        boxes[1][1],
        boxes[1][3],
        boxes[1][0],
        boxes[1][2]
    )
    
    # shuffles the third box
    (
        boxes[2][0],
        boxes[2][1],
        boxes[2][2],
        boxes[2][3],
        boxes[2][4],
        boxes[2][5],
        boxes[2][6],
        boxes[2][7],
        boxes[2][8]
    ) = (
        boxes[2][3],
        boxes[2][0],
        boxes[2][1],
        boxes[2][6],
        boxes[2][4],
        boxes[2][2],
        boxes[2][7],
        boxes[2][8],
        boxes[2][5]
    )

    # shuffles the fourth box
    (
        boxes[3][0],
        boxes[3][1],
        boxes[3][2],
        boxes[3][3]
    ) = (
        boxes[3][1],
        boxes[3][3],
        boxes[3][0],
        boxes[3][2]
    )
    
    current_box()
    print("even or zero")
    print("...")

# odd: rotate counterclockwise
def shuffle_odd():
    
    # shuffles the first box
    (
        boxes[0][0],
        boxes[0][1],
        boxes[0][2],
        boxes[0][3],
        boxes[0][4],
        boxes[0][5],
        boxes[0][6],
        boxes[0][7],
        boxes[0][8]
     ) = (
        boxes[0][1],
        boxes[0][2],
        boxes[0][5],
        boxes[0][0],
        boxes[0][4],
        boxes[0][8],
        boxes[0][3],
        boxes[0][6],
        boxes[0][7]
    )

    # shuffles the second box
    (
        boxes[1][0],
        boxes[1][1],
        boxes[1][2],
        boxes[1][3]
    ) = (
        boxes[1][2],
        boxes[1][0],
        boxes[1][3],
        boxes[1][1]
    )

    # shuffles the third box
    (
        boxes[2][0],
        boxes[2][1],
        boxes[2][2],
        boxes[2][3],
        boxes[2][4],
        boxes[2][5],
        boxes[2][6],
        boxes[2][7],
        boxes[2][8]
    ) = (
        boxes[2][1],
        boxes[2][2],
        boxes[2][5],
        boxes[2][0],
        boxes[2][4],
        boxes[2][8],
        boxes[2][3],
        boxes[2][6],
        boxes[2][7]
    )

    # shuffles the fourth box
    (
        boxes[3][0],
        boxes[3][1],
        boxes[3][2],
        boxes[3][3]
    ) = (
        boxes[3][2],
        boxes[3][0],
        boxes[3][3],
        boxes[3][1]
    )
    
    current_box()
    print("odd")
    print("...")


# prime: reverse dots
def shuffle_prime():
    
    # temporarily saves and stores the first box values
    listA=boxes[0][0:9]
    
    # switches the first box values with the third box
    (
        boxes[0][0],
        boxes[0][1],
        boxes[0][2],
        boxes[0][3],
        boxes[0][4],
        boxes[0][5],
        boxes[0][6],
        boxes[0][7],
        boxes[0][8]
     ) = (
        boxes[2][0],
        boxes[2][1],
        boxes[2][2],
        boxes[2][3],
        boxes[2][4],
        boxes[2][5],
        boxes[2][6],
        boxes[2][7],
        boxes[2][8]
    )
    
    # uses the temporary list to refill the third box
    boxes[2].clear()
    i = 0
    while i < 9:
        boxes[2].append(listA[i])
        i += 1
    i = 0
    listA.clear()
    
    # temporarily saves and stores the second box values
    listA=boxes[1][0:5]
    
    # switches the second box values with the fourth box
    (
        boxes[1][0],
        boxes[1][1],
        boxes[1][2],
        boxes[1][3]
    ) = (
        boxes[3][0],
        boxes[3][1],
        boxes[3][2],
        boxes[3][3]
    )

    # uses the temporary list to refill the fourth box
    boxes[3].clear()
    while i < 4:
        boxes[3].append(listA[i])
        i += 1
    i = 0

    current_box()
    print("prime")
    print("...")
    
# next prime: reset all changes
def next_prime():
    box1[0:9] = dBox1[0:9]
    box2[0:4] = dBox2[0:4]
    box3[0:9] = dBox3[0:9]
    box4[0:4] = dBox4[0:4]
    
    current_box()    
    print("next prime")
    print("...")


# duplicate as last: reverse triangles with adjecent squares
def duplicate():
    
    # temporarily stores the first box adjacent values
    listA = []
    listA.append(boxes[0][1])
    listA.append(boxes[0][3])
    listA.append(boxes[0][5])
    listA.append(boxes[0][7])
    # switches adjacent tiles of boxes 1 with 2
    (
        boxes[0][1],
        boxes[0][3],
        boxes[0][5],
        boxes[0][7]
    ) = (
        boxes[1][0],
        boxes[1][1],
        boxes[1][2],
        boxes[1][3]
    )

    # uses the temporary list to refill box 2
    boxes[1].clear()
    for i in range(len(listA)):
        boxes[1].append(listA[i])
        
    # temporarily stores the third box adjacent values
    listA.clear()
    listA.append(boxes[2][1])
    listA.append(boxes[2][3])
    listA.append(boxes[2][5])
    listA.append(boxes[2][7])
    # switches adjacent tiles of boxes 3 with 4
    (
        boxes[2][1],
        boxes[2][3],
        boxes[2][5],
        boxes[2][7]
    ) = (
        boxes[3][0],
        boxes[3][1],
        boxes[3][2],
        boxes[3][3]
    )

    #uses the temporary list to refill box 4
    boxes[3].clear()
    for i in range(len(listA)):
        boxes[3].append(listA[i])
        
    current_box()
    print("duplicate")
    print("...")


# sample list
#shuf = [6, 8, 8, 9, 7, 7]

shuffles = [shuffle_even, shuffle_odd, shuffle_prime,
                next_prime, duplicate]

def shuffle_call(shuf):

    current_box()
    print("...")
    # available shuffle function list
    # even = 0, odd = 1, prime = 2, duplicate prime = 3, duplicate = 4
    # shuffles in use
    activeShuffles = []
    # last used shuffle
    lastshuffle = 0
    # last used prime number
    lastprime = 0

    # uses numbers in shuf[] to determine which shuffle to use
    lastshuffle, lastprime, appending = is_dupe(shuf, lastshuffle, lastprime)
    activeShuffles.append(appending)
    
    for i in range(len(activeShuffles)):
        shuffles[activeShuffles[i]]()

        
    # returns the index of non-duplicate numbers
def return_even_odd_prime(num):
    # even = 0, odd = 1, prime = 2
    if num % 2 == 0:
        return 0
    elif is_prime(num):
        return 2
    else:
        return 1


    # checks if a number is duplicate, and updates last numbers used
def is_dupe(num, lastshuffle, lastprime):
    shuffle = lastshuffle
    prime = lastprime
    # prime = 3, duplicate = 4
    if is_prime(num):
        if num == lastprime:
            appending = 3
        else:
            appending = 2
        prime = num
        shuffle = num
    elif num == lastshuffle:
        appending = 4
        
    else:
        appending = (return_even_odd_prime(num))
        shuffle = num
    return shuffle, prime, appending

    
    # checks if  number is prime
def is_prime(num):
    isprime = True
    x = 2
    while x < num:
        if num % x == 0:
            isprime = False
            break
        x += 1
    return isprime


# end of shuffle calls


# 1  12  15  11  5  0  _  22  1  23  23  24  5  25


def repeat():
    current_box()
    string_to_int()
    int_to_string()
    repeat()


repeat()
#shuffle_call()
